#ifndef NAME_LENGTH_H
#define NAME_LENGTH_H

void letter_count(char *name);

#endif