#ifndef NAME_REVERSE_H
#define NAME_REVERSE_H

void reverse_order(char *name);

#endif